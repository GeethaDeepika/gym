package com.example.Gym.Controller;

import com.example.Gym.Models.GymApp;
import com.example.Gym.Repository.GymRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class Gym {
    @Autowired
    private GymRepository gymRepository;

    @Transactional
    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> gymEntry(@RequestBody GymApp gymApp){
        GymApp gymobj = gymRepository.save(gymApp);
        Map<String, String> response = new HashMap<>();
        response.put("status", "succesfull");
        return ResponseEntity.ok(response);

    }

    @GetMapping("/viewall")
    public ResponseEntity<List<GymApp>> gymList(){
        List<GymApp> gympeople = gymRepository.findAll();
        return ResponseEntity.ok(gympeople);
    }

}
