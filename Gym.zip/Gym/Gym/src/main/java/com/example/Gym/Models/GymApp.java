package com.example.Gym.Models;


import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class GymApp {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    @JsonProperty("memberId")
    private String memberId;

    @JsonProperty("name")
    private String name;

    @JsonProperty("membership")
    private String membership;

    @JsonProperty("activeStatus")
    private String activeStatus;

    @JsonProperty("workoutPlan")
    private String workoutPlan;

    public GymApp(Long id, String membership, String memberId, String name, String activeStatus, String workoutPlan) {
        Id = id;
        this.membership = membership;
        this.memberId = memberId;
        this.name = name;
        this.activeStatus = activeStatus;
        this.workoutPlan = workoutPlan;
    }

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMembership() {
        return membership;
    }

    public void setMembership(String membership) {
        this.membership = membership;
    }

    public String getActiveStatus() {
        return activeStatus;
    }

    public void setActiveStatus(String activeStatus) {
        this.activeStatus = activeStatus;
    }

    public String getWorkoutPlan() {
        return workoutPlan;
    }

    public void setWorkoutPlan(String workoutPlan) {
        this.workoutPlan = workoutPlan;
    }

    public GymApp() {
    }
}
