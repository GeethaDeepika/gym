package com.example.Gym.Repository;

import com.example.Gym.Models.GymApp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GymRepository extends JpaRepository<GymApp, Long> {
}
